library bar;

import 'package:angular2/src/core/annotations/annotations.dart';

@Component(selector: '[soup]')
class MyComponent {}
