# Components

* Different kinds of injections and visibility
* Shadow DOM usage
* 