module.exports = function TraceurParser() {
  return System.get('transpiler/src/parser').Parser;
};