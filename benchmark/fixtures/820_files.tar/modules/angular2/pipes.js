/**
 * Define public API for Angular here.
 */
