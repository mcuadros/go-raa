package intf

type PreProcessor interface {
	Do(line string)
}
