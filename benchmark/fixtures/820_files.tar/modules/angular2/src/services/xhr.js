import {Promise} from 'angular2/src/facade/async';

export class XHR {
  get(url: string): Promise<string> {
    return null;
  }
}
