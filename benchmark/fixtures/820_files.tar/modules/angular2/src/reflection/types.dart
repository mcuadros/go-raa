library reflection.types;

typedef SetterFn(Object obj, value);
typedef GetterFn(Object obj);
typedef MethodFn(Object obj, List args);
