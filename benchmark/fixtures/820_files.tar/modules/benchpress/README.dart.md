Benchpress - a framework for e2e performance tests
=========

The sources for this package are in the main [Angular2](https://github.com/angular/angular) repo. Please file issues and pull requests against that repo.

License: Apache MIT 2.0
