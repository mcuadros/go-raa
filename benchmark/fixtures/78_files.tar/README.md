Harvesterd [![Build Status](https://travis-ci.org/mcuadros/harvesterd.png?branch=master)](https://travis-ci.org/mcuadros/harvesterd)
==============================

Harvesterd is low footprint collector and parser for events and logs. It is written Go that gives a great performance execution

Many inputs are available as csv, json, regexp, apache2, nginx, etc, as weel writers as mongo, elasticsearch and many other interfaces are coming.


### Why Harvesterd?

This project started to give the solution to the problem of import hundred of millions of csv lines from two years ago. By other way i was looking for a pet project to learn Go, and this is how Harvesterd born!

License
-------

MIT, see [LICENSE](LICENSE)
