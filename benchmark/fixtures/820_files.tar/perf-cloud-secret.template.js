module.exports = {
  "private_key_id": "1234",
  "private_key": "-----BEGIN PRIVATE KEY-----SOME PRIVATE KEY-----END PRIVATE KEY-----\n",
  "client_email": "SOME_EMAIL@developer.gserviceaccount.com",
  "client_id": "SOME_ID",
  "type": "service_account"
};