library change_detectoin.change_detection_jit_generator;

class ChangeDetectorJITGenerator {
  ChangeDetectorJITGenerator(typeName, strategy,  records, directiveMementos) {
  }

  generate() {
    throw "Jit Change Detection is not supported in Dart";
  }
}