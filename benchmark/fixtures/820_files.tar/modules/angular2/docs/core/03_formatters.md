# Formatters

Formatters can be appended on the end of the expressions to translate the value to a different format. Typically used
to control the stringification of numbers, dates, and other data, but can also be used for ordering, mapping, and 
reducing arrays. Formatters can be chained.

NOTE: Formatters are known as filters in Angular v1.

Formatters syntax is:

```
// TODO:  provide syntax of formatter here
```


