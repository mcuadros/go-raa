/**
 * @publicModule angular2/angular2
 */
export class OnChange {
  onChange(changes) {
    throw "OnChange.onChange is not implemented";
  }
}
