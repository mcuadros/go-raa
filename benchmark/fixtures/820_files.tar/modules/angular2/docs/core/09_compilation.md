# HTML Template Compilation

* Process by which a HTML template is converted to a ProtoView

1. DOM parse()
2. Macro
3.

# HTML Template

* https://docs.google.com/document/d/1HHy_zPLGqJj0bHMiWPzPCxn1pO5GlOYwmv-qGgl4f_s
* https://docs.google.com/document/d/1kpuR512G1b0D8egl9245OHaG0cFh0ST0ekhD_g8sxtI
* https://docs.google.com/document/d/1DuFQKElIq293FlhQHvAp__NfP1XV9r8femZFMigm4-k
* Must understand without understanding directives
* IDE support
* local variables


# Binding Philosophy

# Binding to Shadow DOM