library foo;

const preDefinedSelector = 'soup';

class MyContext {
  final String selector;
  const MyContext(this.selector);
}
