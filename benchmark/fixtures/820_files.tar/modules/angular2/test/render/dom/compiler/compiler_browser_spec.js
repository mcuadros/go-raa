/*
 * Runs compiler tests using in-browser DOM adapter.
 */

import {runCompilerCommonTests} from './compiler_common_tests';

export function main() {
  runCompilerCommonTests();
}
