package intf

type Record map[string]interface{}
