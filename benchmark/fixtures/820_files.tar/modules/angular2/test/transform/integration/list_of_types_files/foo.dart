library foo;

class MyContext {
  final String s;
  const MyContext(this.s);
}
