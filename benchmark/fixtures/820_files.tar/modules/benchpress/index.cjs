require(require('traceur').RUNTIME_PATH);
module.exports = require('./benchpress.js');
