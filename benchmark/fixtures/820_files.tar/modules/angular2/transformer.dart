library angular2.transformer_dart;

export 'src/transform/transformer.dart';
