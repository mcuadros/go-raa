import 'dart:html';

Rectangle createRectangle(left, top, width, height) {
  return new Rectangle(left, top, width, height);
}

